function FooterComponent() {
    return(
        <div className="FooterComponent">
            <h2>I am a Footer Component !!</h2>
        </div>
    );
}

export default FooterComponent;