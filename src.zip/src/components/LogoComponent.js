function LogoComponent(props) {
    return(
        <div className="LogoComponent">
            <h4>I am a Logo Component with title: {props.input}</h4>
        </div>
    );
}

export default LogoComponent;